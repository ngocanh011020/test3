package GridItem;

public class ProductModel {
    int images,id;
    String namedh;
    String giadh;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImages() {
        return images;
    }

    public void setImages(int images) {
        this.images = images;
    }

    public String getNamedh() {
        return namedh;
    }

    public void setNamedh(String namedh) {
        this.namedh = namedh;
    }

    public String getGiadh() {
        return giadh;
    }
    public void setGiadh(String giadh) {
        this.giadh = giadh;
    }
}
